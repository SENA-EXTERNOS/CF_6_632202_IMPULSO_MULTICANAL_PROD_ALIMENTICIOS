function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6gupUbq6vdm":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

