function ExecuteScript(strId)
{
  switch (strId)
  {
      case "5vonP1CJ2Yv":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

